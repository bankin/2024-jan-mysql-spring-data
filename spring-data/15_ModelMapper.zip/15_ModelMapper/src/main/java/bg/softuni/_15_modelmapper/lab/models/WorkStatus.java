package bg.softuni._15_modelmapper.lab.models;

public enum WorkStatus {
    PRESENT, PAID_TIME_OFF, SICK, UNPAID_TIME_OFF
}
