package bg.softuni._17_json.services;

import org.springframework.stereotype.Service;

@Service
public class AddressService {
}
