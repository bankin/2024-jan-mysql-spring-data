package bg.softuni._17_json.controllers;

import bg.softuni._17_json.dtos.PersonDTO;
import jakarta.validation.Valid;

public class HomeController {

//    public PersonDTO getPerson(int id) {
//        return .....;
//    }

    public void updatePerson(int id, @Valid PersonDTO data) {
    }
}
