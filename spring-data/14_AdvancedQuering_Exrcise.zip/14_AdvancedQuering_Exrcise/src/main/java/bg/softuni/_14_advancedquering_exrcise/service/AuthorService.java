package bg.softuni._14_advancedquering_exrcise.service;


import bg.softuni._14_advancedquering_exrcise.model.entity.Author;

import java.io.IOException;
import java.util.List;

public interface AuthorService {
    void seedAuthors() throws IOException;

    Author getRandomAuthor();

    List<String> getAllAuthorsOrderByCountOfTheirBooks();

    List<String> findAllNamesEndingIn(String ending);

    int getTotalCopiesCountFor(String firstName, String secondName);
}
