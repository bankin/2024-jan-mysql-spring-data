package bg.softuni._14_advancedquering_exrcise.service;


import bg.softuni._14_advancedquering_exrcise.model.entity.Category;

import java.io.IOException;
import java.util.Set;

public interface CategoryService {
    void seedCategories() throws IOException;

    Set<Category> getRandomCategories();
}
