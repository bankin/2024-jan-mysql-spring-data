package bg.softuni._14_advancedquering_exrcise.repository;

import bg.softuni._14_advancedquering_exrcise.model.entity.AgeRestriction;
import bg.softuni._14_advancedquering_exrcise.model.entity.Book;
import bg.softuni._14_advancedquering_exrcise.model.entity.EditionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    List<Book> findAllByReleaseDateAfter(LocalDate releaseDateAfter);

    List<Book> findAllByReleaseDateBefore(LocalDate releaseDateBefore);

    List<Book> findAllByAuthor_FirstNameAndAuthor_LastNameOrderByReleaseDateDescTitle(String author_firstName, String author_lastName);

    List<Book> findAllByAgeRestriction(AgeRestriction ageRestriction);

    List<Book> findAllByEditionTypeAndCopiesLessThan(EditionType type, int copies);

    List<Book> findAllByPriceLessThanOrPriceGreaterThan(BigDecimal lower, BigDecimal upper);

    List<Book> findAllByReleaseDateLessThanOrReleaseDateGreaterThan(LocalDate start, LocalDate end);

    List<Book> findAllByReleaseDateLessThan(LocalDate date);

    List<Book> findAllByTitleContains(String needle);

    List<Book> findAllByAuthorLastNameStartingWith(String name);

    @Query("SELECT COUNT(b) FROM Book b WHERE LENGTH(b.title) > :min")
    int countByTitleLengthGreaterThan(int min);

    BookInfo findByTitle(String title);

    @Query("UPDATE Book b " +
            "SET b.copies = b.copies + :additionalCopies " +
            "WHERE b.id = :id")
    @Modifying
    @Transactional
    int updateBookCopiesById(int id, int additionalCopies);

    // ???
    void deleteByCopiesLessThan(int copies);

    @Procedure
    void callProcedure();
}
