package bg.softuni._14_advancedquering_exrcise.service;


import bg.softuni._14_advancedquering_exrcise.model.entity.AgeRestriction;
import bg.softuni._14_advancedquering_exrcise.model.entity.Book;
import bg.softuni._14_advancedquering_exrcise.model.entity.EditionType;
import bg.softuni._14_advancedquering_exrcise.repository.BookInfo;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public interface BookService {
    void seedBooks() throws IOException;

    List<Book> findAllBooksAfterYear(int year);

    List<String> findAllAuthorsWithBooksWithReleaseDateBeforeYear(int year);

    List<String> findAllBooksByAuthorFirstAndLastNameOrderByReleaseDate(String firstName, String lastName);

    List<String> findTitlesByAgeRestriction(AgeRestriction ageRestriction);

    List<String> findTitlesByEditionAndCopies(EditionType type, int copies);

    List<Book> findAllBooksWithPriceOutsideOf(int lowerBound, int upperBound);

    List<String> findTitlesForBooksNotPublishedIn(int year);

    List<Book> findAllReleasedBefore(LocalDate date);

    List<String> findTitlesContaining(String needle);

    List<String> findTitlesForAuthorNameStartingWith(String lastNameStart);

    int findTitleCountLongerThan(int minLength);

    BookInfo findInfoByTitle(String title);

    void sellCopies(int bookId, int copiesSold);
}
