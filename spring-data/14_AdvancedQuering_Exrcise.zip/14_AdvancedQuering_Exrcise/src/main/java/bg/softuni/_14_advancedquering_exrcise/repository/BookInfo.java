package bg.softuni._14_advancedquering_exrcise.repository;

import bg.softuni._14_advancedquering_exrcise.model.entity.AgeRestriction;
import bg.softuni._14_advancedquering_exrcise.model.entity.EditionType;

import java.math.BigDecimal;

public interface BookInfo {
    String getTitle();
    EditionType getEditionType();
    AgeRestriction getAgeRestriction();
    BigDecimal getPrice();
}
