package bg.softuni._14_advancedquering_exrcise.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
