package bg.softuni._14_advancedquering_exrcise.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
