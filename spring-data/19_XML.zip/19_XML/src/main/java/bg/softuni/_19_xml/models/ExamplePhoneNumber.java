package bg.softuni._19_xml.models;

public class ExamplePhoneNumber {

    private String number;
}
