package bg.softuni._23_mvc_demo.web;

import bg.softuni._23_mvc_demo.service.companies.CompaniesService;
import bg.softuni._23_mvc_demo.service.projects.ProjectsService;
import jakarta.xml.bind.JAXBException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Controller
public class ImportController {

    private CompaniesService companiesService;
    private ProjectsService projectsService;

    public ImportController(CompaniesService companiesService, ProjectsService projectsService) {
        this.companiesService = companiesService;
        this.projectsService = projectsService;
    }

    @GetMapping("/import/xml")
    public String index(Model model) {
        model.addAttribute("areImported", new boolean[] {false, false, false});

        return "xml/import-xml";
    }

    @GetMapping("/import/companies")
    public String importCompanies(Model model) throws IOException {
        String fileContents = getFileContents("companies.xml");

        model.addAttribute("companies", fileContents);

        return "xml/import-companies";
    }

    @PostMapping("/import/companies")
    public String doImportCompanies() throws JAXBException {
        companiesService.importCompanies();

        return "redirect:/import/xml";
    }

    @GetMapping("/import/projects")
    public String importProjects(Model model) throws IOException {
        String fileContents = getFileContents("projects.xml");

        model.addAttribute("projects", fileContents);

        return "xml/import-projects";
    }

    @PostMapping("import/projects")
    public String doImportProjects() throws JAXBException {
        projectsService.importProjects();

        return "redirect:/import/xml";
    }

    private String getFileContents(String filename) throws IOException {
        Path path = Path.of("src", "main", "resources","files", "xmls", filename);
        List<String> lines = Files.readAllLines(path);

        return String.join("\n", lines);
    }
}
