package bg.softuni._23_mvc_demo.persistence.repositories;

import bg.softuni._23_mvc_demo.persistence.entities.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectsRepository extends JpaRepository<Project, Integer> {
}
