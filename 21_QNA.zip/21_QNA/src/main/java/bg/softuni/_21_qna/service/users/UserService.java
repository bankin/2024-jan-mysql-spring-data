package bg.softuni._21_qna.service.users;


import bg.softuni._21_qna.service.users.dtos.UserBasicJsonDTO;

public interface UserService {
    UserBasicJsonDTO getOne(int id);

    void update(UserBasicJsonDTO data);
}
