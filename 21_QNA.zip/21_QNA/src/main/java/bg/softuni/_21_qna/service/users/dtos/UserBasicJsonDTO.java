package bg.softuni._21_qna.service.users.dtos;

import com.google.gson.annotations.Expose;

public class UserBasicJsonDTO {
    @Expose
    private int id;

    @Expose
    private String firstName;

    @Expose
    private String lastName;

    public UserBasicJsonDTO() {}

    public UserBasicJsonDTO(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
