package bg.softuni._21_qna.service.users;

import bg.softuni._21_qna.persistence.models.User;
import bg.softuni._21_qna.persistence.repositories.UserRepository;
import bg.softuni._21_qna.service.users.dtos.UserBasicJsonDTO;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static bg.softuni._21_qna.service.utils.Util.ensureEntityExists;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    private ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;

        this.modelMapper = new ModelMapper();
    }

    @Override
    public UserBasicJsonDTO getOne(int id) {
        User user = ensureUserExits(id);

        return modelMapper.map(user, UserBasicJsonDTO.class);
    }

    @Override
    public void update(UserBasicJsonDTO data) {
        User user = ensureEntityExists(userRepository, data.getId());

        user.setFirstName(data.getFirstName());
        user.setLastName(data.getLastName());

        userRepository.save(user);
    }

    private User ensureUserExits(int id) {
        Optional<User> user = userRepository.findById(id);

        return user.orElseThrow(() -> new RuntimeException("Not found"));
    }
}
