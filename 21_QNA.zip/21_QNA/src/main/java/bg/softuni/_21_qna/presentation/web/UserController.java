package bg.softuni._21_qna.presentation.web;

import bg.softuni._21_qna.service.users.UserService;
import bg.softuni._21_qna.service.users.dtos.UserBasicJsonDTO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public UserBasicJsonDTO getOne() {
        return userService.getOne(1);
    }

    @PostMapping("/update")
    public void updateUser(@Valid UserBasicJsonDTO data) {
        userService.update(data);
    }
}
