package bg.softuni._21_qna.service.users.dtos;

import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "user")
public class UserBasicXmlDTO {

    @XmlElement
    private int id;

    @XmlElement
    private String firstName;

    @XmlElement
    private String lastName;

    /*
    * <root>
        <array-wrapper>
            <array-element>...</array-element>
            <array-element>...</array-element>
            <array-element>...</array-element>
        </array-wrapper>
    * </root>
    *
    * */
//    @XmlElementWrapper(name = "array-wrapper")
//    @XmlElement(name = "array-element")
//    private List<String> something;

    public UserBasicXmlDTO() {}

    public UserBasicXmlDTO(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
