package bg.softuni._21_qna.presentation.cli;

import bg.softuni._21_qna.service.users.dtos.UserBasicJsonDTO;
import bg.softuni._21_qna.service.users.dtos.UserBasicXmlDTO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class Main implements CommandLineRunner {

    private Gson gson;

    public Main(Gson gson) {
        this.gson = gson;
    }

    @Override
    public void run(String... args) throws Exception {
//        formatJson();
//        formatXml();
        formatTime();
    }

    private void formatTime() {
        CreateTime createTime = new CreateTime(13, LocalDateTime.now());

        String json = gson.toJson(createTime);
        System.out.println(json);
    }

    private void formatXml() throws JAXBException {
        UserBasicXmlDTO userBasicXmlDTO =
            new UserBasicXmlDTO(10, "First", "Last");

        JAXBContext jaxbContext = JAXBContext.newInstance(UserBasicXmlDTO.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(userBasicXmlDTO, System.out);

//        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
//        UserBasicXmlDTO result = (UserBasicXmlDTO) unmarshaller.unmarshal(System.in);
    }

    private void formatJson() {
        UserBasicJsonDTO userBasicJsonDTO =
            new UserBasicJsonDTO(10, "First", "LAst");

        String json = gson.toJson(userBasicJsonDTO);

//        UserBasicJsonDTO result = gson.fromJson(input, UserBasicJsonDTO.class);

        System.out.println(json);
    }
}

class CreateTime {
    @Expose
    private int id;

    @Expose
    private LocalDateTime createdAt;

    public CreateTime() {}

    public CreateTime(int id, LocalDateTime createdAt) {
        this.id = id;
        this.createdAt = createdAt;
    }
}
