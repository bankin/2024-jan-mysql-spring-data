package bg.softuni._21_qna.service.utils;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public class Util {

    public static String formatNumber(double number) {
        return null;
    }

    public static <T> T ensureEntityExists(JpaRepository<T, Integer> repo, int id) {
        Optional<T> byId = repo.findById(id);

        return byId.orElseThrow(() -> new RuntimeException("Not found"));
    }
}
